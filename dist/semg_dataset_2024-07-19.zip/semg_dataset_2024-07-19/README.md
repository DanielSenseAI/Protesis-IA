# sEMG + IMU grip recordings, Recording Session 1 (2024-07-19)

Raw recordings and a tidy, reproducible CSV for review.

## Contents

```
raw/data/*.xlsx                         22 raw recordings, one file per take (unmodified)
raw/sessions/                           session metadata sheets (Subjects, grasps dictionary, session log)
raw/acquisition_script_grip_save_data.py   script that produced the raw files
processed/semg_synchronized.csv         all recordings stacked, one row per sample
processed/recordings_index.csv          one row per raw file: rows kept/dropped, SHA-256
build_dataset.py                        raw -> CSV (this is the only step)
SHA256SUMS.txt                          checksums of every file in this bundle
```

## Reproduce

```sh
pip install -r requirements.txt          # pandas, openpyxl
python build_dataset.py                  # writes processed/ from raw/
sha256sum -c SHA256SUMS.txt              # CSV and raw files must match
```

The script is deterministic. Output was produced with Python 3.13, pandas 3.0.5, openpyxl 3.1.5.
Options: `--raw DIR`, `--out DIR`, `--year` (default 2024), `--fs HZ` (adds `time_s`, see below).

## What "synchronized" means here

Each raw row is a single line from the device over serial: `sample, ax, ay, az, gx, gy, gz, t, s1..s8`.
The IMU (accelerometer, gyroscope, temperature) and the 8 sEMG channels are therefore sampled and
transmitted together, and share one firmware sample counter. No resampling, interpolation or
alignment is applied: synchronization comes from the device. The script checks that `sample`
increases by exactly 1 within each file (true for all files; see index).

## CSV columns

| Column | Meaning |
|---|---|
| `recording_id` | 1..19, chronological order of included files |
| `file` | source raw file |
| `grip` | grip label from the file name, case-normalized (`reposo` -> `rest`; `test` = unlabeled test takes) |
| `start_time` | from the file name (local time, 2024-07-19); the file name is stamped when the script starts, so it is the start of the take, not of the first sample |
| `sample_idx` | 0-based row position inside the recording |
| `sample_counter` | raw firmware counter (resets between takes) |
| `ax, ay, az` | accelerometer |
| `gx, gy, gz` | gyroscope |
| `t` | IMU temperature |
| `s1..s8` | sEMG channels 1-8 (raw values as recorded, 0.000-3.3 range) |

Units and scaling are **not** stored in the data; values are as received over serial. Confirm them
against the firmware before quoting physical units. Likewise the sampling rate is **not** recorded:
rows have no time stamps. Pass `--fs` once the rate is confirmed to add `time_s = sample_idx / fs`.

## Cleaning applied (and nothing else)

* 3 files contain only the header row (0 samples) and are excluded: `Lateral_07_19_18_22_39`, `MedWrap_07_19_18_35_01`, `BSphere_07_19_18_42_56`.
* `lateral07_19_16_50_43.xlsx` ends with 1 truncated serial line (`22123, 3918, <empty>...`) that is not a valid sample; it is dropped.
* Values are written with the original precision (6 decimals IMU/temperature, 3 decimals sEMG).

Everything else is kept as recorded, including short takes (`Test_...`, `reposo_...`, `Lateral_07_19_18_22_44`) and all `test` files; filter on `grip` / `file` as needed.

## Recordings

| File | Grip | Start (file name) | Rows raw | Rows kept | Note |
|---|---|---|---|---|---|
| `test07_19_16_36_49.xlsx` | test | 2024-07-19 16:36:49 | 5175 | 5175 |  |
| `test07_19_16_43_55.xlsx` | test | 2024-07-19 16:43:55 | 1365 | 1365 |  |
| `lateral07_19_16_50_43.xlsx` | Lateral | 2024-07-19 16:50:43 | 3920 | 3919 | dropped 1 non-numeric/truncated row(s) at position(s) [3919] |
| `MedWrap07_19_17_07_51.xlsx` | MedWrap | 2024-07-19 17:07:51 | 3953 | 3953 |  |
| `BSphere07_19_17_16_05.xlsx` | BSphere | 2024-07-19 17:16:05 | 4102 | 4102 |  |
| `Ring07_19_17_23_16.xlsx` | Ring | 2024-07-19 17:23:16 | 3964 | 3964 |  |
| `Tripod_07_19_17_29_18.xlsx` | Tripod | 2024-07-19 17:29:18 | 3955 | 3955 |  |
| `PointTripod_07_19_17_37_03.xlsx` | PointTripod | 2024-07-19 17:37:03 | 3910 | 3910 |  |
| `Test_07_19_17_48_25.xlsx` | test | 2024-07-19 17:48:25 | 129 | 129 |  |
| `reposo_07_19_18_09_05.xlsx` | rest | 2024-07-19 18:09:05 | 289 | 289 |  |
| `reposo_07_19_18_12_05.xlsx` | rest | 2024-07-19 18:12:05 | 302 | 302 |  |
| `reposo_07_19_18_13_28.xlsx` | rest | 2024-07-19 18:13:28 | 429 | 429 |  |
| `Lateral_07_19_18_22_39.xlsx` | Lateral | 2024-07-19 18:22:39 | 0 | 0 | empty file, excluded |
| `Lateral_07_19_18_22_44.xlsx` | Lateral | 2024-07-19 18:22:44 | 114 | 114 |  |
| `Lateral_07_19_18_23_53.xlsx` | Lateral | 2024-07-19 18:23:53 | 3939 | 3939 |  |
| `MedWrap_07_19_18_35_01.xlsx` | MedWrap | 2024-07-19 18:35:01 | 0 | 0 | empty file, excluded |
| `MedWrap_07_19_18_35_48.xlsx` | MedWrap | 2024-07-19 18:35:48 | 3986 | 3986 |  |
| `BSphere_07_19_18_42_56.xlsx` | BSphere | 2024-07-19 18:42:56 | 0 | 0 | empty file, excluded |
| `BSphere_07_19_18_44_10.xlsx` | BSphere | 2024-07-19 18:44:10 | 4019 | 4019 |  |
| `Ring_07_19_18_51_30.xlsx` | Ring | 2024-07-19 18:51:30 | 4115 | 4115 |  |
| `Tripod_07_19_19_02_18.xlsx` | Tripod | 2024-07-19 19:02:18 | 4039 | 4039 |  |
| `PointTripod_07_19_19_09_51.xlsx` | PointTripod | 2024-07-19 19:09:51 | 3967 | 3967 |  |

Total: 55,671 rows in 19 recordings.

## Known limitations

* The `sessions/` sheets (Subjects, session log) are mostly empty templates: no subject demographics, start/finish times, or repetition counts were filled in, so the CSV carries no subject identifier.
* No ground-truth movement/cue timing: each file is one grip held/repeated, labeled only by file name.
